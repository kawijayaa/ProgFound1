def putNumber(num, string): # Create new function
    # Use :03d to add leading zeros that makes the length of the integer to 3
    return (f"{num:03d}. {string}") # Return the formatted string