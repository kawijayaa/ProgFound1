# Lab 00 - Programming Foundations 1 2022
# Name : Muhammad Oka
# Student ID : 2206046784

print("Hello! Welcome to Lab 00 for Programming Foundations 1!\n")
print("Please record your attendance by entering your name, student ID, university e-mail, and your hobby below.")

# Ask the user for their name, student ID, email, and hobby
name = input("Name : ")
student_id = input("Student ID : ")
email = input("University E-mail : ")
hobby = input("Hobby : ")

# Ask the user to describe programming
print("\n")
answer = input("Please write one word that describes programming for you!\n")
print(f"Yeah! I also think programming is {answer}!")
print("\n")

# Record the attendance
print(f"Attendance recorded for student {name} with student ID of {student_id} with an email of {email} and hobby of {hobby}.\n")
print("Thank you for coming to today's lab session. See you next week!")